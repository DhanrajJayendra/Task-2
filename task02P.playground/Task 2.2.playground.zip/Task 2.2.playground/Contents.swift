struct Person {
    let name: String
    var inGame: Bool?
}

protocol Rollable {
    //: - TODO: when rolled, the dice should return a number uniformly chosen between 1 and 6
    func roll () -> Int
}

protocol Table {
    //: - TODO: when initialising the player's inGame status, this should be nil to show that
    // they are not in nor out of the game.
    init(player: Person, dice: Rollable)
    
    var player: Person { get set }
    var dice: Rollable { get }
    
    //: - TODO: by starting the game, set the player's status to a non-nil value.
    func startGame()
}

class dice: Rollable {
    func roll () -> Int {
        let randomInt = Int.random(in: 1...6)
        print(randomInt)
        return randomInt
    }
}

class mytable: Table {
    var player: Person
    var dice: Rollable
    required init(player: Person, dice: Rollable) {
         self.player = player
         self.dice = dice
    }

    func startGame(){
        let dice_roll = dice.roll()
        if  dice_roll == 4 || dice_roll == 5 || dice_roll == 6 {
            player.inGame = false
        }else{
            player.inGame = true
        }
    }
}

func isPersonInGame(player: Person) {
    // TODO: if the person is in the game, print "Let's roll 🎲"
    // TODO: if the person is out of the game, print "No dice "
    // TODO: if the person is neither, print "Not sure yet!"
    if player.inGame == true {
        print("Let's roll 🎲")
    }else if player.inGame == false {
        print("No dice ")
    }else {
        print("Not sure yet!")
    }
}

let myplayer = Person(name:"Gamer",inGame:nil)
let mydice = dice()
let my_table = mytable(player:myplayer,dice:mydice)
isPersonInGame(player:my_table.player)
my_table.startGame()
isPersonInGame(player:my_table.player)
