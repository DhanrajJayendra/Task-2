struct Person {
    let name: String
    var inGame: Bool?
}

protocol Rollable {
    //: - TODO: when rolled, the dice should return a number uniformly chosen between 1 and 6
    func roll () -> [Int]
}

class dice: Rollable {
    func roll () -> [Int] {
        var someArray = [Int] ()
        someArray.append(Int.random(in: 1...6))
        someArray.append(Int.random(in: 1...6))
        someArray.append(Int.random(in: 1...6))
        someArray.append(Int.random(in: 1...6))
        someArray.append(Int.random(in: 1...6))
        return someArray
    }
}

protocol ToughTable {
    init(player: Person, dice: [Rollable])
    var player: Person { get set }
    var dice: [Rollable] { get }
    func start()
}

class mytouchtable: ToughTable {
    var player: Person
    var dice: [Rollable]
    required init(player: Person, dice: [Rollable]) {
         self.player = player
         self.dice = dice
    }

    func start(){
        let roll_die  = dice[0].roll()
        var fail_count = 0
        print(roll_die)
        for item in roll_die {
            if  item == 4 || item == 5 || item == 6 {
                fail_count = fail_count + 1
            }
        }
        if fail_count == 0 {
            player.inGame = true
        }else{
            player.inGame = false
            fail_count = 0
        }
    }
}

func isPersonInGame(player: Person) {
    // TODO: if the person is in the game, print "Let's roll 🎲"
    // TODO: if the person is out of the game, print "No dice "
    // TODO: if the person is neither, print "Not sure yet!"
    if player.inGame == true {
        print("Let's roll 🎲")
    }else if player.inGame == false {
        print("No dice ")
    }else {
        print("Not sure yet!")
    }
}

let myplayer = Person(name:"Gamer",inGame:nil)
let mydice = dice()
let my_table = mytouchtable(player:myplayer,dice:[mydice])
isPersonInGame(player:my_table.player)
my_table.start()
isPersonInGame(player:my_table.player)
