/*:
## Task 1
 
### 1.1 Printing your data
 
 Create a function that takes the user's name and then prints it out nicely with a border. It shall do the following:
 
 1. Take a name as an argument
 2. If the name has an even number of characters, use "=" for the top and bottom borders, otherwise use "-".
 3. Print a line above the name, ensuring extra space at the start and end.
 4. Print "| <name> |" where <name> is the name.
 5. Print a line above the name, ensuring extra space at the start and end.
 
 So Nicole would look like:
 
 ==========
| Nicole |
==========
 
 Test a few names to check your output.
 */
func names(name: String)-> String
{

let count = name.count
if count % 2 == 0
{
    print(" ========= ")
    print("|\(name)|")
    print(" ========= ")
}
else
{
    print(" --------- ")
    print("|\(name)|")
    print(" --------- ")
}
return name
}
names(name: "Dhanraj HJ")
names(name: "Darshan")
