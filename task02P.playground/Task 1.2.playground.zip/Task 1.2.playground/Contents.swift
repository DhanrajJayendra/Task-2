struct CDDMAStudent {
    let firstName: String
    let lastName: String
    let mark: Int?
}

func validate(firstName: String, lastName:String, mark:Int?)-> CDDMAStudent? {
  
    guard let unwrappedMark = mark
    else{
         print("You didn't send a mark")
         return nil
          }
    guard unwrappedMark > 0, unwrappedMark <= 100
    else {
        print("Mark of a student should be between 0 and 100")
    return nil
         }
    print("Hi \(firstName) \(lastName) you have scored \(unwrappedMark) marks")
    
    let a = CDDMAStudent(firstName:firstName, lastName:lastName, mark:mark)
    return a

    
}
validate(firstName: "Dhanraj", lastName: "HJ", mark: 50)

